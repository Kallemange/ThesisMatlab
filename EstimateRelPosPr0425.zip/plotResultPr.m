function plotResultPr(r_ab, tVec, residual,trueDir)
figure
hold on
sgtitle('Distance in each direction')
NEDvec=['N'; 'E'; 'D'];
for i=1:3
subplot(4,1,i)
plot(tVec,r_ab(i,:))
xlabel(strcat(NEDvec(i), '-direction, mean: ', ...
        num2str(mean(r_ab(i,:))) ...
))
end
subplot(414)
d=vecnorm(r_ab, 1);
plot(tVec,d)
xlabel('Euclidean distance')


labelVec = ['N-direction'; 'E-direction'; 'D-direction'];
numVec   = ['0', '1', '2'];
figure
sgtitle(strcat('Histogram drift relative estimates from pR, true distance 10m in ', trueDir, '-direction'))
for i=1:3
    subplot(3,1,i)
    histogram(r_ab(i,:)-mean(r_ab(i,:)),'Normalization','probability', 'DisplayStyle', 'stairs');
    hold on
    xlabel(strcat(labelVec(i,:),', mean 2= ', num2str(round(mean(r_ab(i,:)),2)), '[m]', ...
            ', \sigma^2= ', num2str(round(var(r_ab(i,:)),2))  ...
        ))
    
    
end
%Plot the residual histogram
figure
sgtitle('Histogram over reconstruction error')
residualVec=zeros(size(residual,2),1);
for i=1:size(residual,2)
    if(~isempty(residual{i}))
        residualVec(i)=mean(residual{i});
    else
        residualVec(i)=NaN;
    end
    
end
residualVec(isnan(residualVec))=[];
residualHist=histogram(residualVec,'Normalization','probability');
hold on
xline(mean(residualVec), 'LineWidth', 2);
xlabel(strcat('Reconstrucion error mean:', 32, num2str(mean(residualVec)), 32, ', \sigma^2: ', 32, num2str(var(residualVec))))
hold on

figure
sgtitle(strcat('Histogram drift relative estimates from pR, true distance 10m in ', ...
                trueDir, '-direction'))
hold on
colors=['r', 'g', 'b'];
meanstr='mean: ';
varstr ='variance: ';
for i=1:3
    histogram(r_ab(i,:),'Normalization','probability', 'DisplayStyle', 'stairs');    
    meanstr= strcat(meanstr,32, num2str(round(mean(r_ab(i,:)),1)), ', ', 32);
    varstr= strcat(varstr, 32, num2str(round(var(r_ab(i,:)),1)), ', ', 32);
end
legend(labelVec)
xlabel(strcat('NED: ',32,  meanstr(1:end-2), '[m]',32, varstr(1:end-2)))