function [tVec, r_ab, residual]=optimalSolPr(D,u)
%Max value of the distance vector
i_max=size(D,2);
%Distance vector
r_ab        = zeros(3,i_max);
tVec        = zeros(1,i_max);
residual    = cell(1,i_max);

for i=1:length(D)
    %try
    %Find which u to use (latest arrival wrt the raw data)
    j=find([u.ToW]-u(1).ToW<=D(i).ToW, 1, 'last');
    %Find all valid satellites
    [~,iD,iu]   =intersect(D(i).sat, u(j).sv); 
    
    %Find the index representing the median distance, the corresponding
    %satellite, and its index in u.
    %[median_id, median_u]   =findMedianIndex(D(i),u(j),iD,iu);
    %Find the index representing the strongest signal (sum(SNR), the corresponding
    %satellite, and its index in u.
    %persistentSats=findPersistentSats(D);
    [median_id, median_u]   = findMaxSNR(D(i),u(j),iD,iu);
    %Create a matrix with the weights for all signals as per 
    %A GPS Pseudorange Based Cooperative Vehicular Distance Measurement Technique
    W                       = findWMatrix(D(i),iD, median_id);
    
    %Define double difference as DD=D_i-D_j where D_j=median(D)
    try
    DD                      =D(i).dp(iD)-D(i).dp(iD(median_id));
    catch 
        keyboard
    end
    %Remove that value corresponding to D_j from the solution (D_j-D_j:=0)
    DD(median_id)   =[];
    try
    dU              =u(j).dir(iu,:)-u(j).dir(iu(median_u),:);
    catch EM
        keyboard
    end
    dU(median_id,:) =[];
    %Remove all the values which are too big
    %outlier_idx=find(abs(DD)>1e2);
    %DD(outlier_idx) =[];
    %dU(outlier_idx,:)=[];
    

    if length(DD)>=4
        dP          = inv(dU'*W*dU)*dU'*W*DD;
        r_ab(:,i)   = dP(1:3);
        D_hat       = dU*dP;
        residual{i} = DD-D_hat;
            
    else
        if(i>1)
            r_ab(:,i)=r_ab(:,i-1);
        end
    end
    tVec(i)=D(i).ToW;
end




