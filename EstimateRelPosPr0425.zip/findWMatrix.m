function W=findWMatrix(D, iD, median_id)
SNR=D.SNR(iD,:);
SNR(median_id,:)=[];
W=diag((SNR(:,1).^2).*(SNR(:,2).^2)./(SNR(:,1).^2)+(SNR(:,2).^2));

